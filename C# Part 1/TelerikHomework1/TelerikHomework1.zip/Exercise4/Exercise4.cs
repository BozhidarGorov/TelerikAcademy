﻿using System;

class PrintCurrentDateTime
{
    static void Main()
    {
        Console.WriteLine(DateTime.Now);
    }
}

