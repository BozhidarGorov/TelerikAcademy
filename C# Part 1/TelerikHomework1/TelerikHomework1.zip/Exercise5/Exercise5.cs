﻿using System;

class PrintSquare
{
    static void Main()
    {
        Console.WriteLine(12345*12345);
    }
}

