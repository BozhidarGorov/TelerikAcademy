﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exercise7
{
    class Exercise7
    {
        static void Main()
        {
            string year;
            year = Console.ReadLine();
            int result;
            if (int.TryParse(year, out result)) 
            {
                Console.WriteLine(result + 10);
            }
            else
            {
                Console.WriteLine("You haven't entered an integer");
            }
        }
    }
}
