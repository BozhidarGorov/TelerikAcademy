﻿using System;
using System.Text;

namespace TelerikHomework1
{
    class Exercise1
    {
        static void Main()
        {
            Console.WriteLine("Hello C#!");
        }
    }
}
