﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exercise2
{
    class Exercise2
    {
        static void Main()
        {
            Console.WriteLine("Bozhidar Gorov");
        }
    }
}
