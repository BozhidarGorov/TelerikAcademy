﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exercise5
{
    class Exercise5
    {
        static void Main()
        {
            Console.WriteLine(Math.Sqrt(12345));
        }
    }
}
