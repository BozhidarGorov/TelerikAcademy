﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exercise3
{
    class Exercise3
    {
        static void Main()
        {
            Console.WriteLine("1 \n101 \n1001");
        }
    }
}
