﻿using System;

class IntegerRead
{
    static void Main()
    {
        int first = int.Parse(Console.ReadLine());
        int second = int.Parse(Console.ReadLine());
        int third = int.Parse(Console.ReadLine());
        Console.WriteLine("First {0} \nSecond {1} \nThird {2}",first,second,third);
    }
}

