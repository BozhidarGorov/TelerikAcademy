﻿using System;

class IntervalPrint
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        for (int i = 1; i <= n; i++)
        {
            Console.WriteLine("{0}",i);
        }
    }
}

